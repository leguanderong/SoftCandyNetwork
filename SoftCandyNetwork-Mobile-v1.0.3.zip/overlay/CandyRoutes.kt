package ru.shapovalov.bedlam.candy

import ru.shapovalov.bedlam.core.routing.domain.model.Cidr

/** Generated from exactly 191 single-host IPv4 routes. No CIDR widening allowed. */
object CandyRoutes {
    val v4: List<Cidr.V4> by lazy {
        val lines = ROUTES.trimIndent().lineSequence().map(String::trim).filter(String::isNotEmpty).toList()
        check(lines.size == 191 && lines.distinct().size == 191 &&
            lines.contains("123.123.123.123/32") &&
            !lines.contains("175.27.10.218/32")) { "精确路由清单损坏" }
        lines.map(Cidr::parseV4)
    }

    private const val ROUTES = """
__ROUTES__
    """
}
