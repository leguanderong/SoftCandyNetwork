package ru.shapovalov.bedlam.candy

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.Image
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import ru.shapovalov.bedlam.R
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import ru.shapovalov.hysteria.ConnectionState

private val Pink = Color(0xFFFF73AB)
private val Lilac = Color(0xFFEDE0FF)
private val Blue = Color(0xFFD7EDFF)
private val Cream = Color(0xFFFFFBFE)
private val Ink = Color(0xFF283856)
private val Mint = Color(0xFFDDF8EA)

private enum class CandyTab(val label: String, val emoji: String) {
    Home("首页", "⌂"), Service("服务", "♛"), News("消息", "✉"), Settings("设置", "⚙")
}

@Composable
fun CandyContent(
    connection: ConnectionState,
    configured: Boolean,
    hasCard: Boolean,
    lastError: String?,
    onConnect: (String) -> Unit,
    onDisconnect: () -> Unit,
) {
    var tab by remember { mutableStateOf(CandyTab.Home) }
    var card by remember { mutableStateOf("") } // intentionally not rememberSaveable
    var showCard by remember { mutableStateOf(false) }
    val device = LocalConfiguration.current
    val isTablet = device.smallestScreenWidthDp >= 600
    MaterialTheme(colorScheme = lightColorScheme(primary = Pink, surface = Cream, onSurface = Ink)) {
        BoxWithConstraints(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFFDCEFFF), Color(0xFFFFF4FD), Color.White))
            )
        ) {
            val isLandscape = maxWidth > maxHeight
            val content: @Composable () -> Unit = {
                when (tab) {
                    CandyTab.Home -> HomePanel(connection, configured, hasCard, lastError,
                        isTablet, isLandscape, onStart = {
                            if (!hasCard) tab = CandyTab.Service else onConnect("")
                        }, onStop = onDisconnect)
                    CandyTab.Service -> ServicePanel(
                        card, { card = it }, showCard, { showCard = !showCard },
                        hasCard, configured, lastError,
                        activate = { onConnect(card); card = "" },
                        connectSaved = { onConnect("") },
                    )
                    CandyTab.News -> IntroPanel("💌", "消息中心", "暂时没有新的消息", "重要通知会在这里陪伴你")
                    CandyTab.Settings -> IntroPanel("🍬", "关于软糖网络", "甜甜的连接体验", "版本 1.0 · 开源组件遵循 GPL-3.0-or-later")
                }
            }
            when {
                isTablet && isLandscape -> TabletLandscape(tab, { tab = it }, content)
                isTablet -> TabletPortrait(tab, { tab = it }, content)
                isLandscape -> PhoneLandscape(tab, { tab = it }, content)
                else -> PhonePortrait(tab, { tab = it }, content)
            }
        }
    }
}

@Composable
private fun Brand(compact: Boolean = false) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("☁️", fontSize = if (compact) 30.sp else 44.sp)
        Column {
            Text("软糖网络", fontSize = if (compact) 21.sp else 29.sp,
                fontWeight = FontWeight.ExtraBold, color = Ink)
            if (!compact) Text("甜蜜的网络体验，从这里开始 ✨", fontSize = 12.sp,
                color = Color(0xFF7D85A1))
        }
    }
}

@Composable
private fun HomePanel(
    connection: ConnectionState,
    configured: Boolean,
    hasCard: Boolean,
    lastError: String?,
    tablet: Boolean,
    landscape: Boolean,
    onStart: () -> Unit,
    onStop: () -> Unit,
) {
    val connected = connection is ConnectionState.Connected
    val connecting = connection is ConnectionState.Connecting || connection is ConnectionState.Reconnecting
    val title = when {
        connected -> "已连接"
        connecting -> "连接中"
        connection is ConnectionState.Error -> "连接失败"
        else -> "未连接"
    }
    val description = when {
        connected -> "你的甜心通道正在工作～"
        connecting -> "正在努力连接中…"
        !configured -> "请先完成线路配置"
        !hasCard -> "输入卡码，开启甜蜜体验"
        else -> "准备好了，点一下开始吧"
    }
    val scroll = rememberScrollState()
    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(scroll).padding(if (tablet) 22.dp else 14.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        if (!landscape) Brand()
        if (landscape && !tablet) Brand(compact = true)
        if (landscape) {
            Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.Top) {
                Box(Modifier.weight(1.2f)) {
                    ConnectCard(title, description, connected, connecting, configured, onStart, onStop)
                }
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    InfoRow(connected, hasCard)
                }
            }
        } else {
            ConnectCard(title, description, connected, connecting, configured, onStart, onStop)
            InfoRow(connected, hasCard)
        }
        val detail = (connection as? ConnectionState.Error)?.message ?: lastError
        if (!detail.isNullOrBlank()) Text("温馨提示：${detail.take(140)}", color = Color(0xFFA64668), fontSize = 12.sp)
    }
}

@Composable
private fun ConnectCard(title: String, detail: String, connected: Boolean,
                        connecting: Boolean, configured: Boolean,
                        onStart: () -> Unit, onStop: () -> Unit) {
    Surface(shape = RoundedCornerShape(34.dp), color = Color(0xFFFDF8FF),
        shadowElevation = 7.dp, modifier = Modifier.fillMaxWidth()) {
        Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(13.dp)) {
            Image(painter = painterResource(R.drawable.candy_cloud), contentDescription = null,
                modifier = Modifier.fillMaxWidth().height(150.dp), contentScale = ContentScale.Crop)
            Text("当前状态", color = Color(0xFF8190A6), fontSize = 13.sp)
            Text(title, color = Ink, fontSize = 34.sp, fontWeight = FontWeight.ExtraBold)
            Text(detail, color = Color(0xFF828AA4), fontSize = 13.sp, textAlign = TextAlign.Center)
            Button(onClick = if (connected || connecting) onStop else onStart,
                enabled = configured,
                modifier = Modifier.fillMaxWidth().height(66.dp),
                shape = RoundedCornerShape(40.dp),
                colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                Text(if (connected || connecting) "■  断开连接" else "▶  开始加速",
                    fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
            }
        }
    }
}

@Composable
private fun InfoRow(connected: Boolean, hasCard: Boolean) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f)) { InfoCard("♛", "服务状态", if (hasCard) "已保存卡码" else "待激活", Mint) }
            Box(Modifier.weight(1f)) { InfoCard("▣", "到期时间", "尚未同步", Color(0xFFFFE9EC)) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(Modifier.weight(1f)) { InfoCard("✉", "消息中心", "暂无新消息", Lilac) }
            Box(Modifier.weight(1f)) { InfoCard("ϟ", "当前服务", if (connected) "甜心通道" else "等待开启", Blue) }
        }
    }
}

@Composable
private fun InfoCard(icon: String, label: String, value: String, color: Color) {
    Surface(shape = RoundedCornerShape(25.dp), color = color, modifier = Modifier.fillMaxWidth(), shadowElevation = 1.dp) {
        Column(Modifier.padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            Text(icon, color = Pink, fontWeight = FontWeight.Bold, fontSize = 24.sp)
            Text(label, color = Ink, fontSize = 13.sp)
            Text(value, color = Ink, fontWeight = FontWeight.Bold, fontSize = 15.sp)
        }
    }
}

@Composable
private fun ServicePanel(
    card: String, onCardChange: (String)->Unit, showCard: Boolean, toggleReveal: () -> Unit,
    hasCard: Boolean, configured: Boolean, error: String?, activate: () -> Unit,
    connectSaved: () -> Unit,
) {
    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(20.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)) {
        Brand(compact = true)
        Text("🍬 服务中心", fontSize = 27.sp, fontWeight = FontWeight.ExtraBold, color = Ink)
        Surface(shape = RoundedCornerShape(30.dp), color = Color(0xFFFFFAFF), shadowElevation = 5.dp) {
            Column(Modifier.padding(22.dp), verticalArrangement = Arrangement.spacedBy(17.dp)) {
                Text("输入卡码，开启甜蜜体验 ✨", fontWeight = FontWeight.Bold, color = Ink)
                OutlinedTextField(
                    value = card, onValueChange = { if (it.length <= 256) onCardChange(it) },
                    label = { Text("你的卡码") },
                    placeholder = { Text("DC-XXXX-XXXX-XXXX") },
                    visualTransformation = if (showCard) androidx.compose.ui.text.input.VisualTransformation.None else PasswordVisualTransformation(),
                    modifier = Modifier.fillMaxWidth(), shape = RoundedCornerShape(20.dp),
                    singleLine = true,
                    trailingIcon = { TextButton(onClick = toggleReveal) { Text(if (showCard) "隐藏" else "查看") } },
                )
                Button(onClick = activate, enabled = configured && card.isNotBlank(),
                    modifier = Modifier.fillMaxWidth().height(54.dp),
                    shape = RoundedCornerShape(28.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Pink)) {
                    Text("激活并连接", fontWeight = FontWeight.Bold)
                }
                if (hasCard) {
                    Text("已保存卡码，可直接继续连接", color = Color(0xFF51966C))
                    OutlinedButton(onClick = connectSaved, modifier = Modifier.fillMaxWidth()) { Text("使用已保存的服务") }
                }
                if (!configured) Text("线路资料尚未完成，请由管理员配置后安装。", color = Color(0xFFAD5878))
                if (!error.isNullOrBlank()) Text(error.take(160), color = Color(0xFFAD5878), fontSize = 12.sp)
                Text("到期时间将在服务端支持查询后显示，不使用虚构日期。", fontSize = 12.sp,
                    color = Color(0xFF77829A))
            }
        }
    }
}

@Composable
private fun IntroPanel(emoji: String, title: String, primary: String, secondary: String) {
    Column(Modifier.fillMaxSize().padding(25.dp), horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center) {
        Text(emoji, fontSize = 82.sp)
        Spacer(Modifier.height(15.dp))
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.Bold, color = Ink)
        Spacer(Modifier.height(13.dp))
        Text(primary, fontSize = 16.sp, color = Ink)
        Spacer(Modifier.height(5.dp))
        Text(secondary, fontSize = 13.sp, color = Color(0xFF8994AE), textAlign = TextAlign.Center)
    }
}

@Composable
private fun Navigation(tab: CandyTab, select: (CandyTab)->Unit, vertical: Boolean = false) {
    if (vertical) {
        Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
            CandyTab.entries.forEach { item ->
                val selected = item == tab
                Surface(shape = RoundedCornerShape(22.dp), color = if (selected) Color(0xFFFFDDEB) else Color.Transparent,
                    modifier = Modifier.fillMaxWidth().clickable { select(item) }) {
                    Row(Modifier.padding(14.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text(item.emoji, fontSize = 19.sp, color = if (selected) Pink else Ink)
                        Text(item.label, color = if (selected) Pink else Ink, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal)
                    }
                }
            }
        }
    } else {
        NavigationBar(containerColor = Color.White.copy(alpha = 0.90f)) {
            CandyTab.entries.forEach { item ->
                NavigationBarItem(selected = item == tab, onClick = { select(item) },
                    icon = { Text(item.emoji, fontSize = 22.sp) },
                    label = { Text(item.label) }, alwaysShowLabel = true)
            }
        }
    }
}

@Composable
private fun PhonePortrait(tab: CandyTab, select: (CandyTab)->Unit, content: @Composable () -> Unit) {
    Scaffold(containerColor = Color.Transparent, bottomBar = { Navigation(tab, select) }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad)) { content() }
    }
}

@Composable
private fun PhoneLandscape(tab: CandyTab, select: (CandyTab)->Unit, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Surface(color = Color(0xFFFAF5FF), modifier = Modifier.width(86.dp)) {
            Column(Modifier.fillMaxHeight().padding(5.dp), verticalArrangement = Arrangement.SpaceEvenly) {
                CandyTab.entries.forEach { item ->
                    Column(Modifier.fillMaxWidth().clickable { select(item) }.padding(6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally) {
                        Text(item.emoji, fontSize = 22.sp)
                        Text(item.label, fontSize = 11.sp, color = if (item == tab) Pink else Ink)
                    }
                }
            }
        }
        Box(Modifier.weight(1f)) { content() }
    }
}

@Composable
private fun TabletPortrait(tab: CandyTab, select: (CandyTab)->Unit, content: @Composable () -> Unit) {
    Scaffold(containerColor = Color.Transparent, bottomBar = { Navigation(tab, select) }) { pad ->
        Box(Modifier.fillMaxSize().padding(pad).padding(horizontal = 32.dp), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.widthIn(max = 850.dp)) { content() }
        }
    }
}

@Composable
private fun TabletLandscape(tab: CandyTab, select: (CandyTab)->Unit, content: @Composable () -> Unit) {
    Row(Modifier.fillMaxSize()) {
        Surface(color = Color(0xFFF9F4FF), modifier = Modifier.width(210.dp)) {
            Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(35.dp)) {
                Brand(compact = true)
                Navigation(tab, select, vertical = true)
                Spacer(Modifier.weight(1f))
                Text("让世界更近一点～ 💕", color = Color(0xFFB380A5), fontSize = 12.sp)
            }
        }
        Box(Modifier.weight(1f).fillMaxHeight().padding(horizontal = 28.dp), contentAlignment = Alignment.TopCenter) {
            Box(Modifier.widthIn(max = 1180.dp)) { content() }
        }
    }
}
