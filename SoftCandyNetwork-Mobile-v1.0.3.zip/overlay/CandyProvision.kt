package ru.shapovalov.bedlam.candy

import android.content.Context
import org.json.JSONObject
import ru.shapovalov.bedlam.core.profile.domain.model.Profile
import ru.shapovalov.hysteria.config.HysteriaConfig
import ru.shapovalov.hysteria.config.ServerCredentials
import ru.shapovalov.hysteria.config.TlsOptions
import java.net.Inet4Address
import java.net.InetAddress

/** Public connection data only. Never put a card/password or a private key in assets. */
object CandyProvision {
    private fun json(context: Context): JSONObject = JSONObject(
        context.assets.open("candy_provision.json").bufferedReader().use { it.readText() }
    )

    fun isReady(context: Context): Boolean = runCatching {
        val data = json(context)
        val ip = data.getString("server_ip")
        val addr = InetAddress.getByName(ip)
        addr is Inet4Address && !addr.isAnyLocalAddress && !addr.isLoopbackAddress &&
            data.getInt("port") in 1..65535 &&
            data.getString("sni").isNotBlank() &&
            data.getString("certificate_pem").contains("-----BEGIN CERTIFICATE-----") &&
            data.getString("certificate_sha256").matches(Regex("[0-9A-Fa-f]{64}"))
    }.getOrDefault(false)

    fun newProfile(context: Context, card: String): Profile {
        require(isReady(context)) { "线路尚未配置" }
        val data = json(context)
        val token = card.trim()
        require(token.length in 16..256 && !token.any(Char::isWhitespace)) { "卡码格式有误" }
        return Profile.new(
            name = "甜心通道",
            config = HysteriaConfig(
                server = ServerCredentials(
                    address = "${data.getString("server_ip")}:${data.getInt("port")}",
                    auth = token,
                ),
                tls = TlsOptions(
                    tlsSni = data.getString("sni"),
                    tlsInsecure = false,
                    tlsPinSHA256 = data.getString("certificate_sha256"),
                    tlsCa = data.getString("certificate_pem"),
                ),
            ),
            now = System.currentTimeMillis(),
        )
    }
}
