# 软糖网络 v1.0.2 · 安卓加速器工程（源码/构建包）

## 本包是什么

这是一个**已编写的 Android UI + HY2 真实网络核心的源码覆盖工程**（非 APK）。
编译时 GitHub Actions 会克隆固定版本的开源 [Bedlam](https://github.com/0xSVV/Bedlam)
Android HY2 客户端，并应用 `tooling/patch_upstream.py` 中的补丁，将其转换为
包名 `com.softcandy.network`、应用名「软糖网络」的单节点卡密 APP。

采用 Bedlam 已实现的 Hysteria 2 QUIC、Android VpnService / TUN、后台通知与断线恢复，
**当前上游最低 Android API 29（Android 10），不是 Android 8。** 低于 Android 10 的设备需要另行适配，当前不作兼容承诺。
而不是从零伪造/模拟连接。

采用 Bedlam 是为了复用已有的真实客户端代码；衍生程序继续遵守 **GPL-3.0-or-later**，
必须保留版权与许可证信息。上游为 0xSVV/Bedlam，固定 SHA
`a0143caab68a8d6ca7ccb60316a12e28d388c7fd`。如上游需要升级，需重新评估补丁兼容性。

## 已经实现/写入源码

-「软糖网络」品牌/糖果云朵素材/粉色按钮/卡密页/消息页/设置页。
- Android Compose 根据窗口尺寸切换：手机竖屏、手机横屏、平板竖屏、平板横屏。
- 直接使用 Android 系统 VPN 授权（不偷偷跳过系统弹窗）。
- 凭真实 HY2 连接状态更新 UI，而非假连接按钮。
- 将输入卡密作为 HY2 认证字段，由你服务器上的 `auth:command` 检验。
- AndroidKeyStore AES-GCM 加密保存数据库里的连接配置（卡密在配置内部）。
- 191 个原样 `/32` 目标路由，`123.123.123.123` 为验证页，其余 190 个交给服务端 ACL。
- IPv4 其他目标不纳入 VPN；IPv6 配为绕开 VPN。客户端不执行任何 IP 重写，交给服务端 ACL。
- GitHub Actions 取固定源代码 + Go/gomobile/NDK + Gradle 编译并上传 Debug APK。
- 强制缺少节点配置时构建失败，避免分发假可用 APK。

## 已配置的服务器资料

你之前展示的服务器内网 IP 是 `10.1.0.7`，**不是客户端可用的公网 IPv4**。
已根据确认信息将公网 IP **106.53.199.192** 写入 `assets/candy_provision.json`。
公开 TLS 证书已从用户提供的服务器输出写入，已离线核对 SHA-256、SNI、有效期；还未实际对节点进行 HY2 握手测试。

如未来证书轮换，才需要在 Ubuntu 26.04 **新节点**上把本包中的 `tooling/export_from_server.py` 上传到 `/root/`，运行：

```bash
sudo python3 /root/export_from_server.py 106.53.199.192
```

脚本核验配置的服务器 IP，并检查 `/etc/hysteria/delta-cert.pem`、`/etc/hysteria/client-routes.txt`，
生成 `/root/candy_provision.json`。它只读取，不改 HY2、不重启服务，
**不会导出私钥/卡密/管理员 token**。

使用 MT 管理器 SFTP 下载 `/root/candy_provision.json` 到手机，
替换本工程 `assets/candy_provision.json`。

> 证书是服务端公开证书，放入 APK 不是私钥泄漏。卡密不要预先写入这个文件。

## 从手机用 GitHub Actions 构建

1. 在 GitHub 创建一个新仓库（可以取 `SoftCandyNetwork`）。
2. 将 ZIP 解压，保持 `.github/workflows/build-apk.yml`、`tooling/`、`assets/`、`overlay/` 的原有目录结构上传到仓库根目录。
3. `assets/candy_provision.json` 已包含 IP、公开证书和 SHA-256 指纹，不需要重复导出。未来服务器更换证书时才需要替换。
4. 打开仓库 Actions →「软糖网络 · 编译 APK」→ Run workflow。
5. 成功后在该次运行的 Artifacts 下载 `SoftCandyNetwork-v1.0.2-debug-apk`。
6. 解压得到 Debug APK，在手机上安装。首次运行输入你自己生成的卡密。
7. 第一次开启加速时，Android 会要求用户确认系统 VPN 授权，这是正常且必须的步骤。
8. 连接后用 `http://123.123.123.123/` 测试验证页；服务器通过 `sudo delta-auth online` 看在线状态。

## 重要：当前尚未宣称完成的部分

- 此运行环境**没有完整的 Android SDK/NDK 与 Gradle 编译链**，所以没有实机编译的 APK，只有源码、补丁静态检查和构建工作流。
- 未与您的真实 HY2 公网节点联调；证书、卡密、生效时间均需要真实节点验证。
- HY2 的 `auth:command` 握手本身并不向客户端返回卡密到期时间，所以「到期时间」暂时显示**尚未同步**。不搭建公网卡密后台的条件下，如需真实到期时间，需要另做经鉴权的只读状态同步。
- “消息中心”当前为空状态，无伪造公告。
- 目前没有模拟器截图/功耗长测；四套 UI 是真实代码布局，但还需要在真机/平板上验证。
- APK 按照 GPL-3.0-or-later 继续开放对应衍生作品源码。不要把它当作不受 GPL 约束的封闭商用代码。

## 文件说明

- `.github/workflows/build-apk.yml` — 云端自动编译。
- `tooling/patch_upstream.py` — 对固定的 Bedlam 上游应用源码应用 UI / VPN 路由 / 卡密补丁。
- `tooling/export_from_server.py` — 在新服务器导出公开连接资料。
- `tooling/verify.py` — 路由 / 证书配置自动检查。
- `assets/route-v4.txt` — 精确 191 个 /32 IPv4，不修改、不扩充。
- `assets/candy_provision.json` — 待填写的公网节点公开连接参数。
- `overlay/CandyContent.kt` — 四套 Compose UI。
- `overlay/CandyProvision.kt` — 连接配置和卡密构造。
- `overlay/CandyRoutes.kt` — 编译时生成的精确路由 Kotlin 类模板。
- `overlay/CandyCrypto.kt` — Android Keystore AES-GCM。
- `overlay/candy_cloud.webp` — 从已确认的效果图提取的吉祥物视觉素材。

## 诊断

本地可运行：

```bash
python3 tooling/verify.py
```

确认当前证书确实已导入（现在应当通过）：

```bash
python3 tooling/verify.py --require-provision
```

如 GitHub Actions 编译失败，请提供失败步骤的末尾日志，以便对齐依赖及上游 API。

## v1.0.2 · 证书同步说明

- 新节点地址：`106.53.199.192:443/UDP`
- SNI：`delta-connect.local`
- 公开证书有效期（UTC）：2026-10-18 08:05:40 ～ 2036-10-15 08:05:40
- X.509 DER SHA-256：`228496a8ee5ddbc066baa20644d7911fdc583e14442ebedcfeca0d4e5e8866a5`
- 卡密不会写入 APK；首次运行通过服务页输入，服务器完成认证。
- 此包包含的是项目覆盖层，不含上游 Bedlam 全量源码。CI 将下载固定源码后应用补丁。因当前运行环境缺少 Android SDK/NDK 且无法连接公网，不保证 CI 首次成功，须根据 Actions 日志修正兼容性。

