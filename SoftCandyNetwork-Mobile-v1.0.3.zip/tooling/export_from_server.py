#!/usr/bin/env python3
"""Run on the user's own Ubuntu HY2 node. Exports PUBLIC certificate only, not keys/card.

Usage: sudo python3 export_from_server.py <PUBLIC_IPV4>
Output: /root/candy_provision.json ; copy to assets/ before GitHub build.
"""
import hashlib, ipaddress, json, pathlib, re, sys, ssl

if len(sys.argv) != 2:
    sys.exit('用法：sudo python3 export_from_server.py 节点公网IPv4')
ip = ipaddress.ip_address(sys.argv[1])
if ip.version != 4 or not ip.is_global:
    sys.exit('必须提供真实公网 IPv4，不能使用 10.1.0.7 等内网地址')
cert_file = pathlib.Path('/etc/hysteria/delta-cert.pem')
cert = cert_file.read_text(encoding='ascii')
if '-----BEGIN CERTIFICATE-----' not in cert:
    sys.exit('证书格式错误')
der = ssl.PEM_cert_to_DER_cert(cert)
fp = hashlib.sha256(der).hexdigest()
routefile = pathlib.Path('/etc/hysteria/client-routes.txt')
routes = [x.strip() for x in routefile.read_text().splitlines() if x.strip() and not x.lstrip().startswith('#')]
if len(routes) != 191 or len(set(routes)) != 191 or '123.123.123.123/32' not in routes:
    sys.exit('路由数量不正确，停止导出')
output = pathlib.Path('/root/candy_provision.json')
output.write_text(json.dumps({'server_ip':str(ip),'port':443,'sni':'delta-connect.local',
    'certificate_pem':cert,'certificate_sha256':fp},ensure_ascii=False,indent=2)+'\n')
output.chmod(0o600)
print('已导出',output,'证书 SHA256',fp)
print('这是 PUBLIC 证书，不包含卡密或私钥。用 MT 管理器下载并替换本工程 assets/candy_provision.json。')
