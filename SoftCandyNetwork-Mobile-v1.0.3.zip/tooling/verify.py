#!/usr/bin/env python3
import ipaddress, json, pathlib, unittest, hashlib, ssl
ROOT=pathlib.Path(__file__).resolve().parents[1]
routes=[x.strip() for x in (ROOT/'assets/route-v4.txt').read_text().splitlines() if x.strip() and not x.startswith('#')]
class RouteTests(unittest.TestCase):
    def test_exact_count(self): self.assertEqual(len(routes),191)
    def test_unique(self): self.assertEqual(len(set(routes)),191)
    def test_host_routes(self):
        self.assertTrue(all(ipaddress.ip_network(x,strict=True).prefixlen==32 for x in routes))
    def test_verify_ip(self): self.assertEqual(routes.count('123.123.123.123/32'),1)
    def test_not_redirect_destination(self): self.assertNotIn('175.27.10.218/32',routes)
    def test_provision(self):
        c=json.loads((ROOT/'assets/candy_provision.json').read_text())
        self.assertEqual(c['sni'],'delta-connect.local')
        self.assertEqual(c['port'],443)
        # Server IP may be known before the public TLS certificate is exported.
        self.assertTrue(ipaddress.ip_address(c['server_ip']).is_global)
        pem = c['certificate_pem']
        fingerprint = c['certificate_sha256']
        if not pem:
            self.assertFalse(fingerprint)
        else:
            self.assertIn('BEGIN CERTIFICATE', pem)
            self.assertRegex(fingerprint,r'^[a-fA-F0-9]{64}$')
            actual = hashlib.sha256(ssl.PEM_cert_to_DER_cert(pem)).hexdigest()
            self.assertEqual(actual, fingerprint.lower())
if __name__ == '__main__':
    result=unittest.main(verbosity=2, exit=False, argv=[__import__('sys').argv[0]]).result
    if not result.wasSuccessful(): raise SystemExit(1)
    if '--require-provision' in __import__('sys').argv:
        conf=json.loads((ROOT/'assets/candy_provision.json').read_text())
        if (not conf.get('certificate_pem') or not conf.get('certificate_sha256')):
            raise SystemExit('ERROR: 已配置公网 IPv4，但仍缺少服务器的公开 TLS 证书。请在新节点运行导出脚本后替换 assets/candy_provision.json。')
