#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "${ROOT}"
python3 tooling/verify.py --require-provision
cd "${GITHUB_WORKSPACE}"

git clone https://github.com/0xSVV/Bedlam.git upstream
git -C upstream checkout a0143caab68a8d6ca7ccb60316a12e28d388c7fd
git -C upstream submodule update --init --recursive

python3 "${ROOT}/tooling/patch_upstream.py" upstream

sdkmanager 'ndk;29.0.14206865' 'platforms;android-37'
export ANDROID_NDK_HOME="${ANDROID_HOME}/ndk/29.0.14206865"

pushd upstream/hysteria/golib >/dev/null
mobile_version="$(go list -m -f '{{.Version}}' golang.org/x/mobile)"
go install "golang.org/x/mobile/cmd/gomobile@${mobile_version}" "golang.org/x/mobile/cmd/gobind@${mobile_version}"
popd >/dev/null
export PATH="$(go env GOPATH)/bin:$PATH"

cd upstream
chmod +x gradlew
./gradlew :app:assembleDebug --stacktrace --no-daemon
cd "${GITHUB_WORKSPACE}"
mkdir -p dist
find upstream/app/build/outputs/apk -type f -name '*.apk' -exec cp {} dist/ \;
compgen -G 'dist/*.apk' >/dev/null || { echo "Build produced no APK"; exit 1; }
(cd dist && sha256sum ./*.apk > SHA256SUMS.txt)
ls -lah dist
