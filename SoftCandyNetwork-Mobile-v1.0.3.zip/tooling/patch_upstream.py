#!/usr/bin/env python3
"""Deterministic overlay patch for pinned 0xSVV/Bedlam source. GPLv3-or-later derivative.

Run: python3 tooling/patch_upstream.py /path/to/Bedlam
Does not fetch the internet or modify the HY2 server.
"""
from __future__ import annotations
import ipaddress
import json
import pathlib
import re
import shutil
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
UPSTREAM = 'a0143caab68a8d6ca7ccb60316a12e28d388c7fd'
MODULE = 'app/src/main/kotlin/ru/shapovalov/bedlam'

def replace_once(path: pathlib.Path, old: str, new: str):
    data = path.read_text()
    count = data.count(old)
    if count != 1:
        raise RuntimeError(f'patch mismatch: {path}: {old[:95]!r} count={count}')
    path.write_text(data.replace(old, new, 1))


def main():
    if len(sys.argv) != 2:
        sys.exit('usage: python3 tooling/patch_upstream.py <Bedlam checkout>')
    base = pathlib.Path(sys.argv[1]).resolve()
    if not (base/'app/build.gradle.kts').exists():
        sys.exit('not a Bedlam source checkout')
    if (base/'.git').exists():
        rev = subprocess.check_output(['git','-C',str(base),'rev-parse','HEAD'], text=True).strip()
        if rev != UPSTREAM:
            sys.exit(f'Bedlam upstream changed: expected {UPSTREAM}, got {rev}. Review patches first.')
    routes = [line.strip() for line in (ROOT/'assets/route-v4.txt').read_text().splitlines()
              if line.strip() and not line.strip().startswith('#')]
    assert len(routes) == 191 and len(set(routes)) == 191
    assert all(ipaddress.ip_network(x, strict=True).prefixlen == 32 for x in routes)
    assert '123.123.123.123/32' in routes
    assert '175.27.10.218/32' not in routes
    prov = json.loads((ROOT/'assets/candy_provision.json').read_text())
    assert prov['port'] == 443 and prov['sni'] == 'delta-connect.local'
    # User-facing UI and credential protection
    dest = base/MODULE/'candy'
    dest.mkdir(parents=True, exist_ok=True)
    for file in (ROOT/'overlay').glob('*.kt'):
        data=file.read_text()
        if file.name=='CandyRoutes.kt':
            data=data.replace('__ROUTES__', '\n'.join('        '+x for x in routes))
        (dest/file.name).write_text(data)
    (base/'app/src/main/assets').mkdir(exist_ok=True,parents=True)
    shutil.copy2(ROOT/'assets/candy_provision.json',base/'app/src/main/assets/candy_provision.json')
    (base/'app/src/main/res/drawable').mkdir(parents=True, exist_ok=True)
    shutil.copy2(ROOT/'overlay/candy_cloud.webp', base/'app/src/main/res/drawable/candy_cloud.webp')

    # App ID may differ from Kotlin class namespace; manifest components remain valid.
    gradle=base/'app/build.gradle.kts'
    replace_once(gradle,'applicationId = "ru.shapovalov.bedlam"','applicationId = "com.softcandy.network"')

    manifest=base/'app/src/main/AndroidManifest.xml'
    replace_once(manifest,'android:icon="@mipmap/ic_launcher"','android:icon="@drawable/ic_softcandy"')
    replace_once(manifest,'android:roundIcon="@mipmap/ic_launcher_round"','android:roundIcon="@drawable/ic_softcandy"')
    manifest_text = manifest.read_text()
    manifest_text = manifest_text.replace('<uses-permission android:name="android.permission.REQUEST_INSTALL_PACKAGES" />', '')
    manifest_text = manifest_text.replace('<uses-permission\n        android:name="android.permission.QUERY_ALL_PACKAGES"\n        tools:ignore="QueryAllPackagesPermission" />', '')
    view_intent = '''            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="hysteria2" />
                <data android:scheme="hy2" />
            </intent-filter>'''
    if view_intent not in manifest_text: raise RuntimeError('unrecognized upstream intent filter')
    manifest.write_text(manifest_text.replace(view_intent, ''))
    # App label for system VPN permission/notification, no fake consent dialogs.
    strings=base/'app/src/main/res/values/strings.xml'
    replace_once(strings,'<string name="app_name">Bedlam</string>','<string name="app_name">软糖网络</string>')
    text=strings.read_text()
    for old,new in [
        ('<string name="notification_title">Bedlam</string>','<string name="notification_title">软糖网络</string>'),
        ('<string name="vpn_session_default">Bedlam</string>','<string name="vpn_session_default">软糖网络</string>'),
        ('<string name="qs_tile_label">Bedlam</string>','<string name="qs_tile_label">软糖网络</string>'),
    ]:
        if old in text: text=text.replace(old,new)
    strings.write_text(text.replace("Bedlam", "软糖网络"))

    drawable=base/'app/src/main/res/drawable/ic_softcandy.xml'
    drawable.write_text('''<?xml version="1.0" encoding="utf-8"?>
<vector xmlns:android="http://schemas.android.com/apk/res/android" android:width="108dp"
 android:height="108dp" android:viewportWidth="108" android:viewportHeight="108">
 <path android:fillColor="#FFE1F0FF" android:pathData="M0,0h108v108h-108z"/>
 <path android:fillColor="#FFFF83B6" android:pathData="M24,68 C10,67 10,48 26,45 C23,28 42,21 52,33 C68,21 88,34 82,50 C96,56 93,73 78,75 L28,75Z"/>
 <path android:fillColor="#FF2C3657" android:pathData="M40,53a3,4 0,1 0,6 0a3,4 0,1 0,-6 0 M63,53a3,4 0,1 0,6 0a3,4 0,1 0,-6 0"/>
 <path android:strokeColor="#FFB24473" android:strokeWidth="2.5" android:strokeLineCap="round" android:fillColor="@android:color/transparent" android:pathData="M49,61 Q55,67 61,61"/>
 <path android:fillColor="#FFFFD95F" android:pathData="M76,23 L79,31 87,32 81,38 83,45 76,41 69,45 71,38 65,32 73,31 Z"/>
</vector>
''')

    # At every route-plan build (including reconnect/network change), ONLY 191 /32 destinations.
    planner=base/MODULE/'core/routing/engine/RoutePlanner.kt'
    replace_once(planner,'return if (supportsExcludeRoute) {','val candidate = if (supportsExcludeRoute) {')
    replace_once(planner,'\n    private fun resolveDnsUpstream(','''
    private fun resolveDnsUpstream(''') # preflight anchor, no-op
    # Need insert before end of fun plan() after the candidate if/else block.
    anchor='''        }
    }

    private fun resolveDnsUpstream('''
    repl='''        }
        // SoftCandy: exact allowlist routed by Android VpnService. No 0.0.0.0/0,
        // no CIDR widening, no automatic DNS host route that expands scope.
        return candidate.copy(
            claimedV4 = ru.shapovalov.bedlam.candy.CandyRoutes.v4,
            claimedV6 = emptyList(),
            excludedV4 = emptyList(),
            excludedV6 = emptyList(),
            dnsServers = emptyList(),
            ipv6Enabled = false,
            ipv6Mode = Ipv6Mode.BypassOnly,
            directDnsDomains = emptyList(),
        )
    }

    private fun resolveDnsUpstream('''
    replace_once(planner,anchor,repl)

    # Room storage for connection profile is encrypted using AndroidKeyStore.
    converter=base/MODULE/'core/profile/data/local/HysteriaConfigConverter.kt'
    replace_once(converter,'private val json: Json)', 'private val json: Json)') # match exactly, no-op preflight
    replace_once(converter,'fun toJson(config: HysteriaConfig): String = json.encodeToString(config)',
        'fun toJson(config: HysteriaConfig): String = ru.shapovalov.bedlam.candy.CandyCrypto.seal(json.encodeToString(config))')
    replace_once(converter,'json.decodeFromString<HysteriaConfig>(value)',
        'json.decodeFromString<HysteriaConfig>(ru.shapovalov.bedlam.candy.CandyCrypto.open(value))')

    # Retain native socket protect, QUIC, reconnect/watchdog and VPN permissions.
    activity=base/MODULE/'MainActivity.kt'
    replace_once(activity,'import androidx.lifecycle.lifecycleScope',
        '''import androidx.lifecycle.lifecycleScope
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import ru.shapovalov.bedlam.candy.CandyContent
import ru.shapovalov.bedlam.candy.CandyProvision
import ru.shapovalov.bedlam.core.vpn.VpnRuntimeState
import ru.shapovalov.bedlam.core.vpn.VpnRuntimeStateRepository
import ru.shapovalov.bedlam.core.vpn.effectiveWith
import ru.shapovalov.hysteria.api.HysteriaClient''')
    replace_once(activity,'    private val profileRepository: ProfileRepository by injected { profileRepository }',
        '''    private val profileRepository: ProfileRepository by injected { profileRepository }
    private val hysteriaClient: HysteriaClient by injected { hysteriaClient }
    private val runtimeRepository: VpnRuntimeStateRepository by injected { vpnRuntimeStateRepository }
    private var candyError by mutableStateOf<String?>(null)''')
    startup='''        val rootContext = defaultComponentContext()
        root = appComponent.rootComponentFactory.create(
            rootContext,
            { profile -> requestVpnPermissionThen(profile) },
            { stopVpnService() },
        )
        if (savedInstanceState == null) handleImportIntent(intent)'''
    replace_once(activity,startup,"        // SoftCandy dedicated Compose shell owns navigation; no upstream import UI.")
    replace_once(activity,'setContent { BedlamTheme { RootContent(root) } }', '''setContent {
            BedlamTheme {
                val current by hysteriaClient.state.collectAsState()
                val runtime by runtimeRepository.state.collectAsState(initial = VpnRuntimeState())
                val activeProfileId by profileRepository.observeActiveId().collectAsState(initial = null)
                CandyContent(
                    connection = current.effectiveWith(runtime),
                    configured = CandyProvision.isReady(this@MainActivity),
                    hasCard = activeProfileId != null,
                    lastError = candyError,
                    onConnect = ::connectWithCard,
                    onDisconnect = ::stopVpnService,
                )
            }
        }''')
    replace_once(activity,'    private fun startVpnService(profile: Profile) {', '''    private fun connectWithCard(card: String) {
        lifecycleScope.launch {
            try {
                candyError = null
                val profile = if (card.isNotBlank()) {
                    val created = CandyProvision.newProfile(this@MainActivity, card)
                    profileRepository.upsert(created)
                    profileRepository.setActiveId(created.id)
                    created
                } else {
                    val saved = profileRepository.getActiveId()
                    saved?.let { profileRepository.get(it) }
                        ?: throw IllegalStateException("请先输入卡码")
                }
                requestVpnPermissionThen(profile)
            } catch (e: Exception) {
                candyError = e.message ?: "无法连接，请检查卡码"
            }
        }
    }

    private fun startVpnService(profile: Profile) {''')
    # Header assets and attribution
    (base/'SOFTCANDY_CHANGELOG.md').write_text('''# 软糖网络 1.0

This application adapts Bedlam (GPL-3.0-or-later) with a new Chinese candy-themed UI,
card-login HY2 credentials, non-exportable AndroidKeyStore encryption and 191 exact IPv4 routes.
Bedlam copyright belongs to its original authors. Network code is not proprietary.
Server IP and PUBLIC certificate must be provisioned before release.
''')
    print('Candy overlay applied. Routes: 191, applicationId: com.softcandy.network')

if __name__ == '__main__':
    main()
